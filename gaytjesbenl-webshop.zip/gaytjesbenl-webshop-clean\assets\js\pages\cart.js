/*
  assets/js/pages/cart.js
  - Render cart items
  - Qty aanpassen + remove
  - Totals berekenen
*/

(function () {
  "use strict";

  const cartList = document.getElementById("cartList");
  const cartEmpty = document.getElementById("cartEmpty");
  const cartMeta = document.getElementById("cartMeta");

  const sumSubtotal = document.getElementById("sumSubtotal");
  const sumShipping = document.getElementById("sumShipping");
  const sumTotal = document.getElementById("sumTotal");
  const btnClear = document.getElementById("btnClear");
  const btnCheckout = document.getElementById("btnCheckout");

  const SHIPPING = 4.95;

  function setText(el, v) {
    if (el) el.textContent = v;
  }

  function row(product, qty) {
    const wrap = document.createElement("div");
    wrap.className = "cartRow";

    const thumb = document.createElement("div");
    thumb.className = "cartThumb";
    if (product.img) {
      const img = document.createElement("img");
      img.className = "cartThumbImg";
      img.alt = product.name;
      img.loading = "lazy";
      img.src = product.img;
      thumb.appendChild(img);
    }

    const left = document.createElement("div");
    left.innerHTML = `<div class="strong">${product.name}</div><div class="muted small">${product.category} • ${product.sku || "-"}</div>`;

    const qtyInput = document.createElement("input");
    qtyInput.className = "input";
    qtyInput.type = "number";
    qtyInput.min = "1";
    qtyInput.value = String(qty);

    qtyInput.addEventListener("change", () => {
      const q = Math.max(1, Math.floor(Number(qtyInput.value) || 1));
      window.Store.setCartQty(product.id, q);
      window.dispatchEvent(new Event("cartChanged"));
      boot();
    });

    const price = document.createElement("div");
    price.className = "strong";
    price.style.textAlign = "right";
    price.textContent = window.Store.formatMoney(product.price * qty);

    const remove = document.createElement("button");
    remove.className = "iconBtn";
    remove.title = "Verwijderen";
    remove.textContent = "×";
    remove.addEventListener("click", () => {
      window.Store.setCartQty(product.id, 0);
      window.dispatchEvent(new Event("cartChanged"));
      boot();
    });

    wrap.appendChild(thumb);
    wrap.appendChild(left);
    wrap.appendChild(qtyInput);
    wrap.appendChild(price);
    wrap.appendChild(remove);

    return wrap;
  }

  async function boot() {
    if (!window.Store) return;

    const cart = window.Store.readCart();
    const cartIds = Object.keys(cart);

    if (!cartIds.length) {
      if (cartEmpty) cartEmpty.style.display = "block";
      if (cartList) cartList.innerHTML = "";
      setText(cartMeta, "0 items");
      setText(sumSubtotal, window.Store.formatMoney(0));
      setText(sumShipping, window.Store.formatMoney(0));
      setText(sumTotal, window.Store.formatMoney(0));
      if (btnCheckout) btnCheckout.classList.add("btnGhost");
      return;
    }

    if (cartEmpty) cartEmpty.style.display = "none";

    let products = [];
    try {
      products = await window.Store.loadProducts();
    } catch (_e) {
      setText(cartMeta, "Kon producten niet laden.");
      return;
    }

    let subtotal = 0;
    if (cartList) cartList.innerHTML = "";

    for (const id of cartIds) {
      const qty = Math.max(0, Math.floor(Number(cart[id]) || 0));
      if (qty <= 0) continue;

      const p = products.find((x) => String(x.id) === String(id));
      if (!p) continue;

      subtotal += p.price * qty;
      if (cartList) cartList.appendChild(row(p, qty));
    }

    const shipping = subtotal > 0 ? SHIPPING : 0;
    const beforeCredit = subtotal + shipping;

    setText(cartMeta, `${window.Store.getCartCount(cart)} items`);
    setText(sumSubtotal, window.Store.formatMoney(subtotal));
    setText(sumShipping, window.Store.formatMoney(shipping));
    setText(sumTotal, window.Store.formatMoney(beforeCredit));
  }

  if (btnClear) {
    btnClear.addEventListener("click", () => {
      window.Store.clearCart();
      window.dispatchEvent(new Event("cartChanged"));
      boot();
    });
  }

  boot();
})();
