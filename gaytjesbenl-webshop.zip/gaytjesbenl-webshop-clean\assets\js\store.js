/*
  assets/js/store.js

  Store:
  - Laadt producten uit data/products.json
  - Winkelwagen in localStorage
*/

(function () {
  "use strict";

  const STORE_KEY = "gaytjesbenl.cart.v1";
  const CURRENCY = "EUR";
  const LOCALE = "nl-BE";
  const SHIPPING_FLAT = 4.95;

  function safeParse(jsonText, fallback) {
    try {
      const t = JSON.parse(jsonText);
      return t ?? fallback;
    } catch (_e) {
      return fallback;
    }
  }

  function formatMoney(amount) {
    const n = Number(amount);
    if (!Number.isFinite(n)) return "-";
    try {
      return new Intl.NumberFormat(LOCALE, { style: "currency", currency: CURRENCY }).format(n);
    } catch (_e) {
      return `${n.toFixed(2)} ${CURRENCY}`;
    }
  }

  async function loadProducts() {
    const res = await fetch("data/products.json", { cache: "no-store" });
    if (!res.ok) throw new Error("products_fetch_failed");
    const data = await res.json();
    if (!data || !Array.isArray(data.products)) throw new Error("products_bad_format");
    return data.products;
  }

  function readCart() {
    const raw = localStorage.getItem(STORE_KEY);
    const cart = safeParse(raw || "{}", {});
    if (!cart || typeof cart !== "object") return {};
    return cart;
  }

  function writeCart(cartObj) {
    localStorage.setItem(STORE_KEY, JSON.stringify(cartObj || {}));
  }

  function getCartCount(cartObj) {
    const c = cartObj || readCart();
    let total = 0;
    for (const k of Object.keys(c)) {
      const qty = Number(c[k]);
      if (Number.isFinite(qty) && qty > 0) total += qty;
    }
    return total;
  }

  function addToCart(productId, qty) {
    const id = String(productId || "");
    const q = Math.max(1, Math.floor(Number(qty) || 1));
    if (!id) return false;

    const cart = readCart();
    cart[id] = Math.max(0, Math.floor(Number(cart[id]) || 0)) + q;
    writeCart(cart);
    return true;
  }

  function setCartQty(productId, qty) {
    const id = String(productId || "");
    const q = Math.floor(Number(qty) || 0);
    if (!id) return false;

    const cart = readCart();
    if (q <= 0) {
      delete cart[id];
    } else {
      cart[id] = q;
    }
    writeCart(cart);
    return true;
  }

  function clearCart() {
    writeCart({});
  }

  async function computeCartTotals(opts) {
    const cart = readCart();
    const ids = Object.keys(cart);
    if (!ids.length) {
      return {
        items: 0,
        subtotal: 0,
        shipping: 0,
        total: 0
      };
    }

    const products = await loadProducts();

    let items = 0;
    let subtotal = 0;
    for (const id of ids) {
      const qty = Math.max(0, Math.floor(Number(cart[id]) || 0));
      if (qty <= 0) continue;
      const p = products.find((x) => String(x.id) === String(id));
      if (!p) continue;
      items += qty;
      subtotal += Number(p.price) * qty;
    }

    const shipping = subtotal > 0 ? SHIPPING_FLAT : 0;
    const total = subtotal + shipping;

    return {
      items,
      subtotal,
      shipping,
      total
    };
  }

  window.Store = {
    formatMoney,
    loadProducts,
    readCart,
    writeCart,
    getCartCount,
    addToCart,
    setCartQty,
    clearCart,
    computeCartTotals,
    SHIPPING_FLAT
  };
})();
