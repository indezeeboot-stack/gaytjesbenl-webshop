/*
  assets/js/pages/home.js
  - Laad producten
  - Zoek/filter
  - Render product grid
*/

(function () {
  "use strict";

  const grid = document.getElementById("productGrid");
  const loadState = document.getElementById("loadState");
  const resultMeta = document.getElementById("resultMeta");
  const searchInput = document.getElementById("searchInput");
  const categorySelect = document.getElementById("categorySelect");
  const btnClearCart = document.getElementById("btnClearCart");

  let allProducts = [];

  function uniq(arr) {
    return Array.from(new Set(arr)).filter(Boolean).sort();
  }

  function currentFilters() {
    return {
      q: (searchInput && searchInput.value || "").trim().toLowerCase(),
      cat: (categorySelect && categorySelect.value || "").trim()
    };
  }

  function matchProduct(p, f) {
    if (f.cat && p.category !== f.cat) return false;
    if (!f.q) return true;

    const hay = `${p.name} ${p.category} ${p.sku}`.toLowerCase();
    return hay.includes(f.q);
  }

  function card(p) {
    const wrap = document.createElement("div");
    wrap.className = "card productCard";

    const thumb = document.createElement("div");
    thumb.className = "productThumb";
    if (p.img) {
      const img = document.createElement("img");
      img.className = "productThumbImg";
      img.alt = p.name;
      img.loading = "lazy";
      img.src = p.img;
      thumb.appendChild(img);
    } else {
      thumb.textContent = "Afbeelding placeholder";
    }

    const title = document.createElement("div");
    title.className = "productTitle";
    title.textContent = p.name;

    const row = document.createElement("div");
    row.className = "rowBetween";

    const price = document.createElement("div");
    price.className = "price";
    const compareAt = Number(p.compareAt);
    const now = Number(p.price);
    if (Number.isFinite(compareAt) && Number.isFinite(now) && compareAt > now) {
      const was = document.createElement("span");
      was.className = "priceWas";
      was.textContent = window.Store.formatMoney(compareAt);

      const cur = document.createElement("span");
      cur.className = "priceNow";
      cur.textContent = window.Store.formatMoney(now);

      price.appendChild(was);
      price.appendChild(document.createTextNode(" "));
      price.appendChild(cur);
    } else {
      price.textContent = window.Store.formatMoney(p.price);
    }

    const cat = document.createElement("div");
    cat.className = "tag tagSoft";
    cat.textContent = p.category;

    row.appendChild(price);
    row.appendChild(cat);

    const actions = document.createElement("div");
    actions.className = "cardActions";

    const a = document.createElement("a");
    a.className = "btn btnGhost";
    a.href = `product.html?id=${encodeURIComponent(p.id)}`;
    a.textContent = "Bekijk";

    const b = document.createElement("button");
    b.className = "btn";
    b.textContent = "In winkelwagen";
    b.addEventListener("click", () => {
      window.Store.addToCart(p.id, 1);
      window.dispatchEvent(new Event("cartChanged"));
      b.textContent = "Toegevoegd";
      setTimeout(() => (b.textContent = "In winkelwagen"), 900);
    });

    actions.appendChild(a);
    actions.appendChild(b);

    wrap.appendChild(thumb);
    wrap.appendChild(title);
    wrap.appendChild(row);
    wrap.appendChild(actions);

    return wrap;
  }

  function render() {
    if (!grid) return;

    const f = currentFilters();
    const filtered = allProducts.filter((p) => matchProduct(p, f));

    grid.innerHTML = "";
    for (const p of filtered) grid.appendChild(card(p));

    if (resultMeta) {
      resultMeta.textContent = `${filtered.length} / ${allProducts.length} producten`;
    }
  }

  async function boot() {
    if (!window.Store) return;

    if (btnClearCart) {
      btnClearCart.addEventListener("click", () => {
        window.Store.clearCart();
        window.dispatchEvent(new Event("cartChanged"));
      });
    }

    try {
      allProducts = await window.Store.loadProducts();

      const cats = uniq(allProducts.map((p) => p.category));
      if (categorySelect) {
        for (const c of cats) {
          const opt = document.createElement("option");
          opt.value = c;
          opt.textContent = c;
          categorySelect.appendChild(opt);
        }
      }

      if (loadState) loadState.textContent = "Producten geladen.";
      render();

      if (searchInput) searchInput.addEventListener("input", render);
      if (categorySelect) categorySelect.addEventListener("change", render);
    } catch (_e) {
      if (loadState) loadState.textContent = "Kon producten niet laden. Controleer data/products.json.";
      if (resultMeta) resultMeta.textContent = "0 producten";
    }
  }

  boot();
})();
