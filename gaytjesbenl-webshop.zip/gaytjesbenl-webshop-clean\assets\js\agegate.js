/*
  assets/js/agegate.js

  18+ gate:
  - Toont overlay als user nog niet bevestigd heeft.
  - Onthoudt keuze in localStorage.
*/

(function () {
  "use strict";

  const KEY = "gaytjesbenl.agegate.v1";

  function $(id) {
    return document.getElementById(id);
  }

  function openGate() {
    const gate = $("ageGate");
    if (!gate) return;

    gate.classList.add("isOpen");
    gate.setAttribute("aria-hidden", "false");

    const yes = $("btnAgeYes");
    if (yes && yes.focus) setTimeout(() => yes.focus(), 30);
  }

  function closeGate() {
    const gate = $("ageGate");
    if (!gate) return;

    gate.classList.remove("isOpen");
    gate.setAttribute("aria-hidden", "true");
  }

  function isAllowed() {
    const v = localStorage.getItem(KEY);
    return v === "yes";
  }

  function setAllowed() {
    localStorage.setItem(KEY, "yes");
  }

  function setDenied() {
    localStorage.setItem(KEY, "no");
  }

  function boot() {
    const gate = $("ageGate");
    if (!gate) return;

    const yes = $("btnAgeYes");
    const no = $("btnAgeNo");

    if (yes) {
      yes.addEventListener("click", () => {
        setAllowed();
        closeGate();
      });
    }

    if (no) {
      no.addEventListener("click", () => {
        setDenied();
        const text = gate.querySelector(".ageGateText");
        if (text) text.textContent = "Sorry — je moet 18+ zijn om deze website te bekijken.";
        if (yes) yes.disabled = true;
        if (no) no.disabled = true;
      });
    }

    if (!isAllowed()) openGate();
  }

  boot();
})();
