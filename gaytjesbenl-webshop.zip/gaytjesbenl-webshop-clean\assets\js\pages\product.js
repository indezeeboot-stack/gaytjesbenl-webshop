/*
  assets/js/pages/product.js
  Product detail:
  - id uit querystring
  - add-to-cart met qty
*/

(function () {
  "use strict";

  const pName = document.getElementById("pName");
  const pCategory = document.getElementById("pCategory");
  const pSku = document.getElementById("pSku");
  const pPrice = document.getElementById("pPrice");
  const pStock = document.getElementById("pStock");
  const pDesc = document.getElementById("pDesc");
  const pImg = document.getElementById("pImg");
  const qtyInput = document.getElementById("qtyInput");
  const btnAdd = document.getElementById("btnAddToCart");
  const noteBox = document.getElementById("noteBox");
  const crumbName = document.getElementById("crumbName");
  const suggestGrid = document.getElementById("suggestGrid");

  function getId() {
    const u = new URL(window.location.href);
    return u.searchParams.get("id") || "";
  }

  function setText(el, v) {
    if (el) el.textContent = v;
  }

  function suggestCard(p) {
    const wrap = document.createElement("div");
    wrap.className = "card productCard";

    const thumb = document.createElement("div");
    thumb.className = "productThumb";
    if (p.img) {
      const img = document.createElement("img");
      img.className = "productThumbImg";
      img.alt = p.name;
      img.loading = "lazy";
      img.src = p.img;
      thumb.appendChild(img);
    } else {
      thumb.textContent = "Afbeelding placeholder";
    }

    const title = document.createElement("div");
    title.className = "productTitle";
    title.textContent = p.name;

    const row = document.createElement("div");
    row.className = "rowBetween";

    const price = document.createElement("div");
    price.className = "price";
    const compareAt = Number(p.compareAt);
    const now = Number(p.price);
    if (Number.isFinite(compareAt) && Number.isFinite(now) && compareAt > now) {
      const was = document.createElement("span");
      was.className = "priceWas";
      was.textContent = window.Store.formatMoney(compareAt);

      const cur = document.createElement("span");
      cur.className = "priceNow";
      cur.textContent = window.Store.formatMoney(now);

      price.appendChild(was);
      price.appendChild(document.createTextNode(" "));
      price.appendChild(cur);
    } else {
      price.textContent = window.Store.formatMoney(p.price);
    }

    const a = document.createElement("a");
    a.className = "btn btnGhost";
    a.href = `product.html?id=${encodeURIComponent(p.id)}`;
    a.textContent = "Bekijk";

    row.appendChild(price);
    row.appendChild(a);

    wrap.appendChild(thumb);
    wrap.appendChild(title);
    wrap.appendChild(row);

    return wrap;
  }

  async function boot() {
    if (!window.Store) return;

    const id = getId();
    if (!id) {
      setText(noteBox, "Geen product-id gevonden.");
      return;
    }

    try {
      const products = await window.Store.loadProducts();
      const p = products.find((x) => String(x.id) === String(id));

      if (!p) {
        setText(noteBox, "Product niet gevonden.");
        return;
      }

      document.title = p.name + " | gaytjesbenl.nl";
      setText(pName, p.name);
      setText(crumbName, p.name);
      setText(pCategory, p.category);
      setText(pSku, "SKU: " + (p.sku || "-"));
      if (pPrice) {
        const compareAt = Number(p.compareAt);
        const now = Number(p.price);
        if (Number.isFinite(compareAt) && Number.isFinite(now) && compareAt > now) {
          pPrice.innerHTML = `${window.Store.formatMoney(compareAt)} <span class="priceNow">${window.Store.formatMoney(now)}</span>`;
          pPrice.classList.add("priceHasWas");
        } else {
          pPrice.textContent = window.Store.formatMoney(p.price);
          pPrice.classList.remove("priceHasWas");
        }
      }
      setText(pStock, p.stock > 0 ? `${p.stock} op voorraad (demo)` : "Niet op voorraad (demo)");
      setText(pDesc, p.description || "Geen beschrijving beschikbaar (placeholder).");

      if (pImg) {
        if (p.img) {
          pImg.src = p.img;
          pImg.alt = p.name;
        } else {
          pImg.removeAttribute("src");
          pImg.alt = "";
        }
      }

      setText(noteBox, "Tip: productdata pas je aan in data/products.json (template). ");

      if (btnAdd) {
        btnAdd.addEventListener("click", () => {
          const qty = Math.max(1, Math.floor(Number(qtyInput && qtyInput.value) || 1));
          window.Store.addToCart(p.id, qty);
          window.dispatchEvent(new Event("cartChanged"));
          setText(noteBox, `Toegevoegd: ${qty}x ${p.name}`);
        });
      }

      if (suggestGrid) {
        const others = products.filter((x) => x.id !== p.id).slice(0, 6);
        suggestGrid.innerHTML = "";
        for (const o of others) suggestGrid.appendChild(suggestCard(o));
      }
    } catch (_e) {
      setText(noteBox, "Kon productdata niet laden. Controleer data/products.json.");
    }
  }

  boot();
})();
