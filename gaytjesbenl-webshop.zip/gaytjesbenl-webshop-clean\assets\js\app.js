/*
  assets/js/app.js
  Globale helpers: nav cart count + footer jaar.
*/

(function () {
  "use strict";

  function setText(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = value;
  }

  function refreshNavCartCount() {
    if (!window.Store) return;
    const c = window.Store.getCartCount();
    setText("navCartCount", String(c));
  }

  function boot() {
    setText("year", String(new Date().getFullYear()));
    refreshNavCartCount();

    window.addEventListener("storage", (e) => {
      if (e.key && e.key.includes("gaytjesbenl.cart")) refreshNavCartCount();
    });

    window.addEventListener("cartChanged", refreshNavCartCount);
  }

  boot();
})();
