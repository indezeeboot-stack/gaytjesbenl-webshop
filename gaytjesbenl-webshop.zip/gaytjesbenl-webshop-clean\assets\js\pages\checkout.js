/*
  assets/js/pages/checkout.js
  Demo checkout:
  - Validate minimal velden
  - Toon totaal
  - "Bevestig" -> leeg cart en toon bericht
*/

(function () {
  "use strict";

  const cName = document.getElementById("cName");
  const cEmail = document.getElementById("cEmail");
  const cAddr = document.getElementById("cAddr");
  const cZip = document.getElementById("cZip");
  const cCity = document.getElementById("cCity");
  const cCountry = document.getElementById("cCountry");

  const btnConfirm = document.getElementById("btnConfirm");
  const checkoutNote = document.getElementById("checkoutNote");

  const coItems = document.getElementById("coItems");
  const coTotal = document.getElementById("coTotal");

  function setText(el, v) {
    if (el) el.textContent = v;
  }

  function validEmail(s) {
    const v = String(s || "").trim();
    return v.includes("@") && v.includes(".");
  }

  async function computeTotals() {
    if (window.Store.computeCartTotals) {
      return await window.Store.computeCartTotals();
    }
    return { items: 0, subtotal: 0, shipping: 0, total: 0 };
  }

  async function boot() {
    if (!window.Store) return;

    try {
      const t = await computeTotals();
      setText(coItems, String(t.items));
      setText(coTotal, window.Store.formatMoney(t.total));
      setText(checkoutNote, t.items > 0 ? "Vul je gegevens in en bevestig (demo)." : "Je winkelwagen is leeg.");
    } catch (_e) {
      setText(checkoutNote, "Kon totaal niet berekenen (controleer products.json).");
    }
  }

  if (btnConfirm) {
    btnConfirm.addEventListener("click", async () => {
      const name = (cName && cName.value || "").trim();
      const email = (cEmail && cEmail.value || "").trim();
      const addr = (cAddr && cAddr.value || "").trim();
      const zip = (cZip && cZip.value || "").trim();
      const city = (cCity && cCity.value || "").trim();
      const country = (cCountry && cCountry.value || "").trim();

      if (!name || !validEmail(email) || !addr || !zip || !city || !country) {
        setText(checkoutNote, "Controleer je gegevens: naam, e-mail, adres, postcode, plaats en land zijn verplicht.");
        return;
      }
      const totals = await computeTotals();
      if (totals.items <= 0) {
        setText(checkoutNote, "Je winkelwagen is leeg.");
        return;
      }

      window.Store.clearCart();
      window.dispatchEvent(new Event("cartChanged"));

      setText(checkoutNote, `Order bevestigd (demo). Totaal: ${window.Store.formatMoney(totals.total)}. Winkelwagen is nu leeg.`);
      await boot();
    });
  }

  boot();
})();
