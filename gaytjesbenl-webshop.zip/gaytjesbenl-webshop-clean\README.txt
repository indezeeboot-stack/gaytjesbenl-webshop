gaytjesbenl.nl — Webshop Template (18+)
======================================

Wat je krijgt
-------------
- Statische webshop (HTML/CSS/JS)
- Producten uit data/products.json
- Winkelwagen in localStorage
- 18+ leeftijdscheck (popup bij openen; onthoudt keuze)
- Demo-checkout (geen echte betaling / geen echte orderopslag)

Online “op te zoeken”
---------------------
Deze map kun je hosten op bv. Netlify / GitHub Pages / webhosting.

Aanpassen
---------
- Producten: data/products.json
- Styling: assets/css/style.css
- 18+ gate tekst/logic: assets/js/agegate.js
